

# Covid-19 Report

A  report on coronavirus (COVID-19) cases, both globally and for states within the SA. This websites data includes:

- Confirmed cases, deaths, and recoveries globally or by country
- Option to see the above information, but only for SA State
- Graphs and Charts to represent the above data visually

## Technologies

- Gatsby.js (React.js)
- Chart.js
- Tailwindscss
- Netlify

