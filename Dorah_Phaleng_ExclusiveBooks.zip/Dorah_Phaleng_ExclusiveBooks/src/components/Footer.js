import React from "react"

const Footer = () => {
  return (
    <footer className="text-gray-500 py-6 bg-gray-900 w-full mt-10">
      <div className="flex flex-wrap md:flex-no-wrap justify-center md:justify-between text-xs sm:text-base px-8 container mx-auto">
        <div className="w-full md:w-auto inline-block text-center">
          Coded with ❤️ by{" "}
          <a
            href=""
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline text-teal-400 font-bold"
          >
            Dorah Phaleng
          </a>
        </div>
        <div className="w-full md:w-auto text-center">
          🔎 Sources:{" "}
          <a
            href="https://api.covid19api.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline text-teal-400 font-bold"
          >
            Covid-API
          </a>{" "}
          |{" "}
          <a
            href="https:" "
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline text-teal-400 font-bold"
          >
            Pomber
          </a>{" "}
          |{" "}
          <a
            href= "https://api.covid19api.com/countries"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline text-teal-400 font-bold"
          >
            API Countries
          </a>
        </div>
      </div>
    </footer>
  )
}

export default Footer
