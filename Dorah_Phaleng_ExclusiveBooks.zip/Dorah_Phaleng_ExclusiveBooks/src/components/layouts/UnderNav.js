import React from "react"

const UnderNav = props => {
  return <div className="pt-24 mobile:pt-16">{props.children}</div>
}

export default UnderNav
